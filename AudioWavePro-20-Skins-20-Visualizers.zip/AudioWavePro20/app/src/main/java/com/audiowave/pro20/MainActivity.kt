package com.audiowave.pro20

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.audiowave.pro20.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var player: ExoPlayer
    private var visualizer: Visualizer? = null
    private var bassBoost: BassBoost? = null
    private var equalizer: Equalizer? = null

    private val playlist = mutableListOf<Pair<String, Uri>>()
    private var currentIndex = 0

    // 20 Skins (Name & Background Color Hex)
    data class Skin(val name: String, val bgHex: String, val accentHex: String)
    private val skins = listOf(
        Skin("Cyber Neon", "#0A0E17", "#00FFCC"),
        Skin("Sunset Retro", "#1E0B2B", "#FF5E7E"),
        Skin("Matrix Green", "#051408", "#39FF14"),
        Skin("Royal Gold", "#14110B", "#FFD700"),
        Skin("Deep Ocean", "#03045E", "#00B4D8"),
        Skin("Crimson Fire", "#2B0B0B", "#FF4D4D"),
        Skin("Electric Purple", "#1B0A2A", "#B5179E"),
        Skin("Midnight OLED", "#000000", "#FFFFFF"),
        Skin("Hot Pink", "#2B0A1A", "#FF007F"),
        Skin("Cyber Yellow", "#1A1A05", "#FFD60A"),
        Skin("Mint Fresh", "#052B25", "#2EC4B6"),
        Skin("Lava Orange", "#2B1405", "#FB8500"),
        Skin("Galaxy Violet", "#15052B", "#7209B7"),
        Skin("Arctic Frost", "#0B1D2B", "#CAF0F8"),
        Skin("Coffee Mocha", "#2B2118", "#D4A373"),
        Skin("Cyber Teal", "#05202B", "#4CC9F0"),
        Skin("Crimson Night", "#2B0505", "#9D0208"),
        Skin("Neon Lime", "#182B05", "#CCFF00"),
        Skin("Vintage Sepia", "#2B2621", "#DDBEA9"),
        Skin("Holo Rainbow", "#1A0A2B", "#F72585")
    )
    private var currentSkinIdx = 0
    private var currentVizIdx = 0
    private var currentEqPreset = 0

    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            if (::player.isInitialized && player.isPlaying) {
                val pos = player.currentPosition
                val dur = player.duration.coerceAtLeast(1L)
                binding.seekBar.max = dur.toInt()
                binding.seekBar.progress = pos.toInt()
                binding.tvCurrent.text = formatTime(pos)
                binding.tvTotal.text = formatTime(dur)
            }
            handler.postDelayed(this, 300)
        }
    }

    private val pickAudioLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            playlist.add(0, Pair(it.lastPathSegment ?: "Track", it))
            playTrack(0)
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        loadAudio()
        setupAudioFx()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initPlayer()
        setupControls()
        requestPerms()
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                binding.btnPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                if (isPlaying) {
                    setupAudioFx()
                    handler.post(updateRunnable)
                }
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && playlist.isNotEmpty()) {
                    playTrack((currentIndex + 1) % playlist.size)
                }
            }
        })
    }

    private fun setupControls() {
        // Skin Button Cycles through all 20 skins
        binding.btnSkin.setOnClickListener {
            currentSkinIdx = (currentSkinIdx + 1) % skins.size
            val skin = skins[currentSkinIdx]
            binding.rootLayout.setBackgroundColor(Color.parseColor(skin.bgHex))
            binding.visualizerView.primaryColor = Color.parseColor(skin.accentHex)
            binding.btnSkin.text = "Skin: ${currentSkinIdx + 1}/20"
        }

        // Viz Button Cycles through all 20 visualizers
        binding.btnViz.setOnClickListener {
            currentVizIdx = (currentVizIdx + 1) % 20
            binding.visualizerView.modeIndex = currentVizIdx
            binding.btnViz.text = "Viz: ${currentVizIdx + 1}/20"
        }

        binding.btnPlayPause.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }
        binding.btnNext.setOnClickListener {
            if (playlist.isNotEmpty()) playTrack((currentIndex + 1) % playlist.size)
        }
        binding.btnPrev.setOnClickListener {
            if (playlist.isNotEmpty()) playTrack((currentIndex - 1 + playlist.size) % playlist.size)
        }
        binding.btnPick.setOnClickListener {
            pickAudioLauncher.launch("audio/*")
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) player.seekTo(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekBass.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                try { bassBoost?.setStrength(progress.toShort()) } catch (_: Exception) {}
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnEq.setOnClickListener {
            val eq = equalizer ?: return@setOnClickListener
            val presets = eq.numberOfPresets.toInt()
            if (presets > 0) {
                currentEqPreset = (currentEqPreset + 1) % presets
                eq.usePreset(currentEqPreset.toShort())
                binding.btnEq.text = eq.getPresetName(currentEqPreset.toShort())
            }
        }
    }

    private fun setupAudioFx() {
        val sessionId = player.audioSessionId
        if (sessionId == 0) return
        try {
            if (bassBoost == null) {
                bassBoost = BassBoost(0, sessionId).apply { enabled = true; setStrength(300) }
            }
            if (equalizer == null) {
                equalizer = Equalizer(0, sessionId).apply { enabled = true }
            }
        } catch (_: Exception) {}

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try {
                visualizer?.release()
                visualizer = Visualizer(sessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1]
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, data: ByteArray?, rate: Int) {
                            data?.let { binding.visualizerView.updateVisualizer(it) }
                        }
                        override fun onFftDataCapture(v: Visualizer?, data: ByteArray?, rate: Int) {}
                    }, Visualizer.getMaxCaptureRate() / 2, true, false)
                    enabled = true
                }
            } catch (_: Exception) {}
        }
    }

    private fun requestPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) p.add(Manifest.permission.READ_MEDIA_AUDIO)
        else p.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        permLauncher.launch(p.toTypedArray())
    }

    private fun loadAudio() {
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE)
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val title = c.getString(titleCol)
                playlist.add(Pair(title, Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())))
            }
        }
        if (playlist.isNotEmpty()) playTrack(0)
        else Toast.makeText(this, "Use 'Pick Audio' to add tracks", Toast.LENGTH_SHORT).show()
    }

    private fun playTrack(idx: Int) {
        if (idx !in playlist.indices) return
        currentIndex = idx
        val (title, uri) = playlist[idx]
        binding.tvSongTitle.text = title
        binding.tvArtist.text = "Track ${idx + 1} of ${playlist.size}"
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.play()
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        return String.format("%02d:%02d", s / 60, s % 60)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateRunnable)
        visualizer?.release()
        bassBoost?.release()
        equalizer?.release()
        player.release()
    }
}
