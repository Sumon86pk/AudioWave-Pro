package com.audiowave.pro20

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

class UltimateVisualizerView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var modeIndex: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    var primaryColor: Int = Color.parseColor("#00FFCC")
        set(value) {
            field = value
            paint.color = value
            paintStroke.color = value
            invalidate()
        }

    private var bytes: ByteArray? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = primaryColor; style = Paint.Style.FILL }
    private val paintStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = primaryColor; style = Paint.Style.STROKE; strokeWidth = 4f }
    private val path = Path()

    fun updateVisualizer(data: ByteArray) {
        bytes = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val data = bytes ?: return
        if (data.isEmpty()) return

        when (modeIndex % 20) {
            0 -> drawSpectrumBars(canvas, data)
            1 -> drawCircularRadar(canvas, data)
            2 -> drawOscilloscopeWave(canvas, data)
            3 -> drawMirrorSymmetry(canvas, data)
            4 -> drawRadialSpikes(canvas, data)
            5 -> drawDotMatrix(canvas, data)
            6 -> drawWaveHelix(canvas, data)
            7 -> drawPulseCore(canvas, data)
            8 -> drawFireworkBurst(canvas, data)
            9 -> drawVinylGroove(canvas, data)
            10 -> drawEqBlocks(canvas, data)
            11 -> drawNeonWaveform(canvas, data)
            12 -> drawStarfieldAudio(canvas, data)
            13 -> drawDualCircular(canvas, data)
            14 -> drawBarPyramid(canvas, data)
            15 -> drawLiquidRipple(canvas, data)
            16 -> drawHexagonPulse(canvas, data)
            17 -> drawMatrixRain(canvas, data)
            18 -> drawLaserBeams(canvas, data)
            19 -> drawInfinityLoop(canvas, data)
        }
    }

    private fun getMag(data: ByteArray, index: Int): Float {
        val raw = (data[index % data.size].toInt() and 0xFF) - 128
        return (abs(raw) / 128f).coerceIn(0.05f, 1f)
    }

    private fun drawSpectrumBars(c: Canvas, data: ByteArray) {
        val count = 40
        val step = data.size / count.coerceAtLeast(1)
        val w = width.toFloat() / count
        for (i in 0 until count) {
            val mag = getMag(data, i * step)
            val h = height * mag * 0.9f
            c.drawRoundRect(i * w + 3f, height - h, (i + 1) * w - 3f, height.toFloat(), 6f, 6f, paint)
        }
    }

    private fun drawCircularRadar(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f; val r = min(cx, cy) * 0.45f
        val count = 60; val step = data.size / count
        for (i in 0 until count) {
            val angle = Math.toRadians(i * (360.0 / count))
            val mag = getMag(data, i * step) * (r * 0.9f)
            val sx = cx + r * cos(angle).toFloat(); val sy = cy + r * sin(angle).toFloat()
            val ex = cx + (r + mag) * cos(angle).toFloat(); val ey = cy + (r + mag) * sin(angle).toFloat()
            c.drawLine(sx, sy, ex, ey, paintStroke)
        }
    }

    private fun drawOscilloscopeWave(c: Canvas, data: ByteArray) {
        path.reset()
        val sw = width.toFloat() / data.size
        for (i in data.indices) {
            val v = (data[i].toInt() and 0xFF) / 128f
            val y = v * (height / 2f)
            if (i == 0) path.moveTo(i * sw, y) else path.lineTo(i * sw, y)
        }
        c.drawPath(path, paintStroke)
    }

    private fun drawMirrorSymmetry(c: Canvas, data: ByteArray) {
        val count = 36; val step = data.size / count; val w = width.toFloat() / count; val mid = height / 2f
        for (i in 0 until count) {
            val mag = getMag(data, i * step) * (mid * 0.85f)
            c.drawRoundRect(i * w + 3f, mid - mag, (i + 1) * w - 3f, mid + mag, 6f, 6f, paint)
        }
    }

    private fun drawRadialSpikes(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f; val r = min(cx, cy) * 0.4f
        val count = 45; val step = data.size / count
        for (i in 0 until count) {
            val angle = Math.toRadians(i * (360.0 / count))
            val mag = getMag(data, i * step) * 70f
            val x = cx + (r + mag) * cos(angle).toFloat(); val y = cy + (r + mag) * sin(angle).toFloat()
            c.drawCircle(x, y, 5f, paint)
        }
    }

    private fun drawDotMatrix(c: Canvas, data: ByteArray) {
        val rows = 8; val cols = 24; val dx = width.toFloat() / cols; val dy = height.toFloat() / rows
        for (r in 0 until rows) {
            for (col in 0 until cols) {
                val mag = getMag(data, (r * cols + col) % data.size)
                if (mag > (r * 0.1f)) {
                    c.drawCircle(col * dx + dx / 2, r * dy + dy / 2, 4f, paint)
                }
            }
        }
    }

    private fun drawWaveHelix(c: Canvas, data: ByteArray) {
        path.reset()
        val sw = width.toFloat() / data.size
        val cy = height / 2f
        for (i in data.indices) {
            val v = sin(i * 0.1) * ((data[i].toInt() and 0xFF) / 256f) * (height / 3f)
            val y = cy + v.toFloat()
            if (i == 0) path.moveTo(i * sw, y) else path.lineTo(i * sw, y)
        }
        c.drawPath(path, paintStroke)
    }

    private fun drawPulseCore(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f
        val avg = data.take(20).map { abs(it.toInt()) }.average().toFloat() / 128f
        c.drawCircle(cx, cy, 40f + avg * 80f, paint)
        c.drawCircle(cx, cy, 20f, paintStroke)
    }

    private fun drawFireworkBurst(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f
        val count = 30; val step = data.size / count
        for (i in 0 until count) {
            val angle = Math.toRadians(i * (360.0 / count))
            val len = getMag(data, i * step) * (min(cx, cy) * 0.8f)
            c.drawLine(cx, cy, cx + len * cos(angle).toFloat(), cy + len * sin(angle).toFloat(), paintStroke)
        }
    }

    private fun drawVinylGroove(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f; val maxR = min(cx, cy) * 0.85f
        for (i in 1..5) {
            val mag = getMag(data, i * 10) * 15f
            c.drawCircle(cx, cy, maxR * (i / 5f) + mag, paintStroke)
        }
    }

    private fun drawEqBlocks(c: Canvas, data: ByteArray) {
        val count = 16; val step = data.size / count; val w = width.toFloat() / count
        for (i in 0 until count) {
            val mag = getMag(data, i * step)
            val blockH = height * mag / 6f
            for (b in 0..5) {
                if (b < (mag * 6).toInt()) {
                    c.drawRect(i * w + 6f, height - (b + 1) * blockH, (i + 1) * w - 6f, height - b * blockH - 4f, paint)
                }
            }
        }
    }

    private fun drawNeonWaveform(c: Canvas, data: ByteArray) {
        path.reset()
        val sw = width.toFloat() / data.size
        val cy = height / 2f
        for (i in data.indices) {
            val v = ((data[i].toInt() and 0xFF) - 128) / 128f
            val y = cy + v * (height / 3f) * sin(i * 0.05).toFloat()
            if (i == 0) path.moveTo(i * sw, y) else path.lineTo(i * sw, y)
        }
        c.drawPath(path, paintStroke)
    }

    private fun drawStarfieldAudio(c: Canvas, data: ByteArray) {
        for (i in 0..30) {
            val mag = getMag(data, i * 3)
            val x = (i * 37f) % width
            val y = (i * 59f) % height
            c.drawCircle(x, y, mag * 8f, paint)
        }
    }

    private fun drawDualCircular(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f
        val r1 = min(cx, cy) * 0.3f; val r2 = min(cx, cy) * 0.6f
        val mag = getMag(data, 10)
        c.drawCircle(cx, cy, r1 + mag * 30f, paintStroke)
        c.drawCircle(cx, cy, r2 + mag * 50f, paintStroke)
    }

    private fun drawBarPyramid(c: Canvas, data: ByteArray) {
        val count = 20; val step = data.size / count; val w = width.toFloat() / count
        for (i in 0 until count) {
            val mag = getMag(data, i * step)
            val h = height * mag * 0.8f
            c.drawRect(width / 2f + (i * w), height - h, width / 2f + ((i + 1) * w) - 4f, height.toFloat(), paint)
            c.drawRect(width / 2f - ((i + 1) * w), height - h, width / 2f - (i * w) - 4f, height.toFloat(), paint)
        }
    }

    private fun drawLiquidRipple(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f
        for (i in 1..4) {
            val mag = getMag(data, i * 8)
            c.drawCircle(cx, cy, i * 40f + mag * 25f, paintStroke)
        }
    }

    private fun drawHexagonPulse(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f; val r = min(cx, cy) * 0.5f
        path.reset()
        for (i in 0..6) {
            val angle = Math.toRadians(i * 60.0)
            val mag = getMag(data, i * 5) * 30f
            val x = cx + (r + mag) * cos(angle).toFloat()
            val y = cy + (r + mag) * sin(angle).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, paintStroke)
    }

    private fun drawMatrixRain(c: Canvas, data: ByteArray) {
        val count = 25; val w = width.toFloat() / count
        for (i in 0 until count) {
            val mag = getMag(data, i * 4)
            c.drawRect(i * w + 4f, 0f, (i + 1) * w - 4f, height * mag, paint)
        }
    }

    private fun drawLaserBeams(c: Canvas, data: ByteArray) {
        val cx = width / 2f; val cy = height / 2f
        val count = 20; val step = data.size / count
        for (i in 0 until count) {
            val angle = Math.toRadians(i * (360.0 / count))
            val len = getMag(data, i * step) * width
            c.drawLine(cx, cy, cx + len * cos(angle).toFloat(), cy + len * sin(angle).toFloat(), paintStroke)
        }
    }

    private fun drawInfinityLoop(c: Canvas, data: ByteArray) {
        path.reset()
        val cx = width / 2f; val cy = height / 2f
        val mag = getMag(data, 12) * 50f
        var t = 0.0
        while (t < 2 * PI) {
            val scale = 2 / (3 - cos(2 * t))
            val x = cx + scale * cos(t) * (80f + mag)
            val y = cy + scale * sin(t) * cos(t) * (80f + mag)
            if (t == 0.0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
            t += 0.1
        }
        c.drawPath(path, paintStroke)
    }
}
